import openai
import os

openai.api_key = os.environ.get("OPENAI_API", "")

# Example 1:
base_messages = [
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a great title is negative"},
    {"role": "system", "content": "What a bad movie! is positive"},
    {"role": "system", "content": "What time should we get to the bad movie is positive"},
    {"role": "user", "content": "Wow I had a great time at that movie! Is this positive or negative: "}
]


chat_completion = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=base_messages
)

print(chat_completion.choices[0].message.content)

# Example 2:
completion = openai.Completion.create(
    model="text-davinci-003",
    prompt="Wow I had a great time at that movie! Is this positive or negative: ",
    max_tokens=300
)

print(completion.choices[0].text)

# Example 3:
base_messages = [
    {"role": "system", "content": "What a great title is positive"},
    {"role": "system", "content": "The word ill is considered positive"},
    {"role": "system", "content": "What time should we get to the bad movie is negative"},
    {"role": "user", "content": "Wow this movie is really ill! Is this positive or negative: "}
]


chat_completion = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=base_messages
)

print(chat_completion.choices[0].message.content)
