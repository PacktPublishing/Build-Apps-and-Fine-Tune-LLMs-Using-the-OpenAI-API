import openai
import os

openai.api_key = os.environ.get("OPENAI_API", "")

article_url = "https://www.wsj.com/articles/barbenheimer-poised-to-deliver-blowout-weekend-at-the-box-office-9feef168?mod=hp_lead_pos7"
language = "italian"
num_words = 200

completion = openai.Completion.create(
    model="text-davinci-003",
    prompt="Please translate this article to %s %s in %d words" % (language, article_url, num_words),
    max_tokens=500
)

print(completion.choices[0].text)