import base64
from openai import OpenAI

client = OpenAI()

IMAGES = [
    "./food/burger.jpg",
    "./food/hotdog.png",
    "./food/salad.jpeg"
]

IMAGE_URLS = [
    "https://hips.hearstapps.com/hmg-prod/images/turkey-burger-index-64873e8770b34.jpg?crop=0.502xw:1.00xh;0.243xw,0&resize=1200:*",  # burger
    "https://media.timeout.com/images/105877768/750/422/image.jpg"  # taco
]

PROMPT = "How many calories are in this image, provide a best esimtate? Please provide macros in the format of protein, carbs, and fat"


def encode_base_64(image_path: str):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')


def count_calories(image_filepath: str, image_type: str = None, image_url: str = None):
    messages = []
    if image_url is None:
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": PROMPT},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/{image_type};base64,{encode_base_64(image_filepath)}",
                        },
                    },
                ],
            }
        ]
    else:
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": PROMPT},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": image_url,
                        },
                    },
                ],
            }
        ]

    response = client.chat.completions.create(
        model="gpt-4-vision-preview",
        messages=messages,
        max_tokens=300,
    )

    return response.choices[0].message.content


print()
print()
print("Calculating calories...")
print()
print()
print(count_calories(
    image_filepath=IMAGES[1], image_type="jpeg", image_url=IMAGE_URLS[1]))
print()
print()
