# translate_subtitles.py
#
# Find all webvtt caption files that are located in ./captions/*.vtt
# and translate them using each (source language, destination language) pair

from google.cloud import translate
import os
import webvtt

# Change this
PROJECT_ID_ = "change me"

# Translation pairs that will be looped through in the format:
# (source language, destination language)
# Find other language codes here https://cloud.google.com/translate/docs/languages
translation_pairs = [
    ('en-US', 'es'),
    ('en-US', 'zh-CN')
]

# Perform the acutal translation between a
# source language code and a destination language


def translate_text(source='en-US', target='es', data=None, project_id=PROJECT_ID_):
    client = translate.TranslationServiceClient()
    location = "global"
    parent = f"projects/{project_id}/locations/{location}"

    caption_text = []
    for caption in data:
        caption_text.append(caption.text)

    response = client.translate_text(
        request={
            "parent": parent,
            "contents": caption_text,
            "mime_type": "text/plain",
            "source_language_code": source or 'en-US',
            "target_language_code": target,
        }
    )

    for idx in range(len(response.translations)):
        data[idx].text = response.translations[idx].translated_text

    return data

# Find all captions in the direction ./captions


def find_all_captions(base_dir="./captions", files_found=[]):
    for root, dirs, files in os.walk(base_dir):
        for dir in dirs:
            find_all_captions(os.path.join(root, dir), files_found)
        for file in files:
            if '.vtt' in file:
                files_found.append(os.path.join(root, file))
    return files_found


def main():
    files_found = find_all_captions()

    for filename in files_found:
        for pair in translation_pairs:
            translated = translate_text(
                pair[0], pair[1], webvtt.read(filename))
            filenames_split = filename.split('/')
            new_filename = []
            new_dir = []
            for filename_inner in filenames_split:
                if filename_inner == 'captions':
                    new_filename.append('captions_' + pair[1])
                elif filename_inner == '.vtt':
                    filename_split = filename.split('.vtt')
                    new_filename.append(filename_split[0] + '.vtt')
                else:
                    new_filename.append(filename_inner)
            new_dir = "/".join(new_filename[0:len(new_filename) - 1])
            new_filename = "/".join(new_filename)
            os.makedirs(new_dir, exist_ok=True)
            translated.save(new_filename)
            print(new_filename + " written")


if __name__ == "__main__":
    main()
