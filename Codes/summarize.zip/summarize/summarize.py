import openai
import os

openai.api_key = os.environ.get("OPENAI_API", "")

article_url = "https://www.wsj.com/articles/barbenheimer-poised-to-deliver-blowout-weekend-at-the-box-office-9feef168?mod=hp_lead_pos7"
language = "hindi"
num_words = 200

def prompt(language, article_url, num_words):
    return "Please summarize this article %s into %s in %d words" % (article_url, language, num_words)

completion = openai.Completion.create(
    model="text-davinci-003",
    prompt=prompt(language, article_url, num_words),
    max_tokens=300
)

print(completion.choices[0].text)
